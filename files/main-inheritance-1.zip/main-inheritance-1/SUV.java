class SUV extends FourWheeler {

    public void makeNoise() {

        System.out.println("SUV's makeNoise()");
    }

    public void start() {

        System.out.println("SUV's start()");
    }
}