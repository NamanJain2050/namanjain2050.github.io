class Scooter extends TwoWheeler {

    public void makeNoise() {

        System.out.println("Scooter's makeNoise()");
    }

    public void start() {

        System.out.println("Scooter's start()");
    }
}