class Hatchbag extends FourWheeler {

    public void makeNoise() {

        System.out.println("Hatchbag's makeNoise()");
    }

    public void start() {

        System.out.println("Hatchbag's start()");
    }
}