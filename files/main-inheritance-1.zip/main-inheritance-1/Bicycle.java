class Bicycle extends TwoWheeler{

    public void makeNoise() {

        System.out.println("Bicycle's makeNoise()");
    }

    public void start() {

        System.out.println("Bicycle's start()");
    }
}