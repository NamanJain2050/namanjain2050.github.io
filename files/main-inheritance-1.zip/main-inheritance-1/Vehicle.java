class Vehicle {

    public int yearOfManufacture;
    public String color;
    public String name;
    public void makeNoise() {

        System.out.println("Vehicle's makeNoise()");
    }

    public void lock() {

        System.out.println("Vehicle's lock()");
    }

    public void start() {

        System.out.println("Vehicle's start()");
    }

    public void drive() {

        System.out.println("Vehicle's drive()");
    }

}