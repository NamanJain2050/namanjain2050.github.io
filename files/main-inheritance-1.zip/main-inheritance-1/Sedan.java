class Sedan extends FourWheeler {

    public void makeNoise() {

        System.out.println("Sedan's makeNoise()");
    }

    public void start() {

        System.out.println("Sedan's start()");
    }
}