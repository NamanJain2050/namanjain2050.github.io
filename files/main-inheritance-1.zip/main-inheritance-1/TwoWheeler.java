class TwoWheeler extends Vehicle {

    public void drive() {

        System.out.println("TwoWheeler's drive()");
    }
}