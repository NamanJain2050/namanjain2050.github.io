class FourWheeler extends Vehicle {

    public void drive() {

        System.out.println("FourWheeler's drive()");
    }
}