class HelperClass {

    public static void main(String[] args) {

        Bicycle bicycle = new Bicycle();
        System.out.println("Bicycle methods");
        bicycle.makeNoise();
        bicycle.lock();
        bicycle.start();
        bicycle.drive();

        Scooter scooter = new Scooter();
        System.out.println("Scooter methods");
        scooter.makeNoise();
        scooter.lock();
        scooter.start();
        scooter.drive();

        SUV suv = new SUV();
        System.out.println("SUV methods");
        suv.makeNoise();
        suv.lock();
        suv.start();
        suv.drive();

        Sedan sedan = new Sedan();
        System.out.println("Sedan methods");
        sedan.makeNoise();
        sedan.lock();
        sedan.start();
        sedan.drive();

        Hatchbag hatchbag = new Hatchbag();
        System.out.println("Hatchbag methods");
        hatchbag.makeNoise();
        hatchbag.lock();
        hatchbag.start();
        hatchbag.drive();

    }
}